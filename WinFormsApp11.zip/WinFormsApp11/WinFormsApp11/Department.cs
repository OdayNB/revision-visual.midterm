﻿using System;

namespace WinFormsApp11
{
    public class Department
    {
        public int DeptID { get; set; }
        public string DeptName { get; set; }

        public Department(int deptID, string deptName)
        {
            DeptID = deptID;
            DeptName = deptName;
        }
    }

    public class Student
    {
        public int StudentID { get; private set; }
        public string Name { get; set; }
        public double Score { get; set; }
        public int DeptID { get; set; }

        public Student(int studentID, string name, double score, int deptID)
        {
            StudentID = studentID;
            Name = name;
            Score = score;
            DeptID = deptID;
        }

        public override string ToString()
        {
            return $"Student ID: {StudentID} | Name: {Name} | Score: {Score}";
        }
    }
}