﻿using System;

namespace WinFormsApp11
{
    public class FoodOrder
    {
        public int ID { get; private set; }
        public string FoodName { get; set; }
        public int Quantity { get; set; }
        public double PricePerItem { get; set; }
        public DateTime OrderDate { get; set; }

        public FoodOrder(int id, string foodName, int quantity, double pricePerItem, DateTime orderDate)
        {
            ID = id;
            FoodName = foodName;
            Quantity = quantity;
            PricePerItem = pricePerItem;
            OrderDate = orderDate;
        }

        public double GetTotalPrice()
        {
            return Quantity * PricePerItem;
        }

        public override string ToString()
        {
            return $"Order #{ID} | Item: {FoodName} | Qty: {Quantity} | Price: ${PricePerItem} | Total: ${GetTotalPrice()} | Date: {OrderDate.ToShortDateString()}";
        }
    }
}