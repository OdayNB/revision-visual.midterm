﻿using System;

namespace WinFormsApp11
{
    public class Car
    {
        public int CarID { get; private set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public double Price { get; set; }

        public Car(int carID, string brand, string model, int year, double price)
        {
            CarID = carID;
            Brand = brand;
            Model = model;
            Year = year;
            Price = price;
        }

        public override string ToString()
        {
            return $"Car ID: {CarID} | Brand: {Brand} | Model: {Model} | Year: {Year} | Price: ${Price}";
        }
    }
}