﻿using System;

namespace WinFormsApp11
{
    public class Book
    {
        public int BookID { get; private set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }

        public Book(int bookID, string title, string category, double price)
        {
            BookID = bookID;
            Title = title;
            Category = category;
            Price = price;
        }

        public override string ToString()
        {
            return $"Book ID: {BookID} | Title: {Title} | Category: {Category} | Price: ${Price}";
        }
    }
}