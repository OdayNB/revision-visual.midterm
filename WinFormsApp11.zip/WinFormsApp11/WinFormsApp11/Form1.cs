using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class Form1 : Form
    {
        // 1. تعريف القوائم العامة (Lists) التي ستجري عليها استعلامات الـ LINQ
        private List<FoodOrder> foodOrders = new List<FoodOrder>();
        private List<Car> cars = new List<Car>();
        private List<Book> books = new List<Book>();
        private List<Student> students = new List<Student>();
        private List<Department> departments = new List<Department>();

        public Form1()
        {
            InitializeComponent();
            LoadData(); // دالة لتعبئة بيانات تجريبية فور فتح البرنامج
        }

        // دالة لإدخال بيانات افتراضية في القوائم لتجربة الـ LINQ مباشرة
        private void LoadData()
        {
            // بيانات الأكل والطلبيات
            foodOrders.Add(new FoodOrder(1, "Pizza Margherita", 2, 8.5, DateTime.Now.AddDays(-2)));
            foodOrders.Add(new FoodOrder(2, "Burger Combo", 3, 6.0, DateTime.Now.AddDays(-1)));
            foodOrders.Add(new FoodOrder(3, "Pasta Alfredo", 1, 10.0, DateTime.Now));

            // بيانات السيارات
            cars.Add(new Car(1, "Toyota", "Camry", 2022, 25000));
            cars.Add(new Car(2, "BMW", "X5", 2023, 65000));
            cars.Add(new Car(3, "Toyota", "Corolla", 2021, 18000));
            cars.Add(new Car(4, "Mercedes", "C200", 2024, 55000));

            // بيانات المكتبة والكتب
            books.Add(new Book(1, "C# Programming", "Programming", 45.0));
            books.Add(new Book(2, "World History", "History", 20.0));
            books.Add(new Book(3, "Advanced LINQ", "Programming", 35.0));
            books.Add(new Book(4, "Database Systems", "Programming", 50.0));
            books.Add(new Book(5, "World History", "History", 20.0)); // تكرار لتجربة Distinct

            // بيانات الأقسام والطلاب للجامعة
            departments.Add(new Department(1, "Computer Science"));
            departments.Add(new Department(2, "Engineering"));

            students.Add(new Student(1, "Ali", 88.5, 1));
            students.Add(new Student(2, "Sara", 95.0, 1));
            students.Add(new Student(3, "Omar", 76.0, 2));
            students.Add(new Student(4, "Laila", 91.0, 2));
        }

        // ==================== القسم الأول: الأكل والطلبيات (Food & Orders) ====================

        private void btn_processFood_Click(object sender, EventArgs e)
        {
            lb_foodResult.Items.Clear();
            if (cb_quantity.SelectedItem == null)
            {
                MessageBox.Show("Please select a quantity!");
                return;
            }

            int qty = int.Parse(cb_quantity.SelectedItem.ToString());
            DateTime orderDate = dtp_order.Value;

            // استخدام LINQ Select أو عرض الطلب الجديد
            lb_foodResult.Items.Add($"New Order Processed! Date: {orderDate.ToShortDateString()}, Quantity: {qty}");
        }

        private void btn_foodLinqSum_Click(object sender, EventArgs e)
        {
            lb_foodResult.Items.Clear();

            // LINQ: Sum (حساب إجمالي الأرباح أو المبيعات)
            double totalRevenue = foodOrders.Sum(o => o.GetTotalPrice());

            lb_foodResult.Items.Add($"=== LINQ SUM Operation ===");
            lb_foodResult.Items.Add($"Total Revenue from all food orders: ${totalRevenue}");
        }

        // ==================== القسم الثاني: السيارات (Cars Management - LINQ) ====================

        private void btn_carsWhere_Click(object sender, EventArgs e)
        {
            lb_carsResult.Items.Clear();
            string searchBrand = txt_carBrand.Text.Trim();

            // LINQ: Where (فلترة السيارات حسب الماركة المدخلة)
            var result = from c in cars
                         where c.Brand.ToLower() == searchBrand.ToLower()
                         select c;

            lb_carsResult.Items.Add($"=== LINQ WHERE (Brand = {searchBrand}) ===");
            foreach (var car in result)
            {
                lb_carsResult.Items.Add(car);
            }

            if (!result.Any())
            {
                lb_carsResult.Items.Add("No cars found matching this brand.");
            }
        }

        private void btn_carsOrderBy_Click(object sender, EventArgs e)
        {
            lb_carsResult.Items.Clear();

            // LINQ: OrderBy & OrderByDescending (ترتيب السيارات حسب السعر تصاعدياً)
            var result = cars.OrderBy(c => c.Price);

            lb_carsResult.Items.Add("=== LINQ ORDERBY (Sorted by Price Ascending) ===");
            foreach (var car in result)
            {
                lb_carsResult.Items.Add(car);
            }
        }

        private void btn_carsSelect_Click(object sender, EventArgs e)
        {
            lb_carsResult.Items.Clear();

            // LINQ: Select (استخلاص أسماء وموديلات السيارات فقط دون باقي التفاصيل)
            var result = cars.Select(c => new { c.Brand, c.Model });

            lb_carsResult.Items.Add("=== LINQ SELECT (Anonymous Type - Brand & Model Only) ===");
            foreach (var item in result)
            {
                lb_carsResult.Items.Add($"Brand: {item.Brand}, Model: {item.Model}");
            }
        }

        // ==================== القسم الثالث: المكتبة (Library System - LINQ) ====================

        private void btn_libWhere_Click(object sender, EventArgs e)
        {
            lb_libraryResult.Items.Clear();
            string category = txt_bookSearch.Text.Trim();

            // LINQ: Where (البحث عن الكتب حسب التصنيف Category)
            var result = books.Where(b => b.Category.Equals(category, StringComparison.OrdinalIgnoreCase));

            lb_libraryResult.Items.Add($"=== LINQ WHERE (Category = {category}) ===");
            foreach (var book in result)
            {
                lb_libraryResult.Items.Add(book);
            }
        }

        private void btn_libGroupBy_Click(object sender, EventArgs e)
        {
            lb_libraryResult.Items.Clear();

            // LINQ: GroupBy (تجميع الكتب حسب التصنيف)
            var result = books.GroupBy(b => b.Category);

            lb_libraryResult.Items.Add("=== LINQ GROUPBY (Books Grouped by Category) ===");
            foreach (var group in result)
            {
                lb_libraryResult.Items.Add($"Category Group: {group.Key} (Count: {group.Count()})");
                foreach (var book in group)
                {
                    lb_libraryResult.Items.Add($"   -> {book.Title} (${book.Price})");
                }
            }
        }

        private void btn_libDistinct_Click(object sender, EventArgs e)
        {
            lb_libraryResult.Items.Clear();

            // LINQ: Distinct (جلب أسماء الكتب الفريدة بدون تكرار)
            var result = books.Select(b => b.Title).Distinct();

            lb_libraryResult.Items.Add("=== LINQ DISTINCT (Unique Book Titles) ===");
            foreach (var title in result)
            {
                lb_libraryResult.Items.Add($"Book Title: {title}");
            }
        }

        // ==================== القسم الرابع: الجامعة والطلاب (University - LINQ) ====================

        private void btn_uniAverage_Click(object sender, EventArgs e)
        {
            lb_uniResult.Items.Clear();

            // LINQ: Average (حساب معدل علامات الطلاب)
            double avgScore = students.Average(s => s.Score);

            lb_uniResult.Items.Add("=== LINQ AVERAGE ===");
            lb_uniResult.Items.Add($"The average score of all students is: {avgScore}");
        }

        private void btn_uniMaxMin_Click(object sender, EventArgs e)
        {
            lb_uniResult.Items.Clear();

            // LINQ: Max & Min (أعلى وأدنى علامة)
            double maxScore = students.Max(s => s.Score);
            double minScore = students.Min(s => s.Score);

            lb_uniResult.Items.Add("=== LINQ MAX & MIN ===");
            lb_uniResult.Items.Add($"Highest Student Score: {maxScore}");
            lb_uniResult.Items.Add($"Lowest Student Score: {minScore}");
        }

        private void btn_uniJoin_Click(object sender, EventArgs e)
        {
            lb_uniResult.Items.Clear();

            // LINQ: Join (ربط جدول الطلاب بجدول الأقسام عبر مفتاح الـ DeptID)
            var result = from s in students
                         join d in departments on s.DeptID equals d.DeptID
                         select new { s.Name, s.Score, d.DeptName };

            lb_uniResult.Items.Add("=== LINQ JOIN (Students with Departments) ===");
            foreach (var item in result)
            {
                lb_uniResult.Items.Add($"Student: {item.Name} | Score: {item.Score} | Department: {item.DeptName}");
            }
        }
    }
}