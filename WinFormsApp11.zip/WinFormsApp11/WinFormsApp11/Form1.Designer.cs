﻿namespace WinFormsApp11
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            newToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();

            // TabControl الرئيسي الشامل لكل الأقسام
            tc_master = new TabControl();

            // ==================== 1. قسم الطلبيات والأكل (Food & Orders) ====================
            tp_food = new TabPage();
            groupBox1 = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            cb_quantity = new ComboBox();
            dtp_order = new DateTimePicker();
            btn_processFood = new Button();
            btn_foodLinqSum = new Button();
            lb_foodResult = new ListBox();

            // ==================== 2. قسم السيارات (Cars Management) ====================
            tp_cars = new TabPage();
            gb_cars = new GroupBox();
            lbl_carBrand = new Label();
            txt_carBrand = new TextBox();
            btn_carsWhere = new Button();
            btn_carsOrderBy = new Button();
            btn_carsSelect = new Button();
            lb_carsResult = new ListBox();

            // ==================== 3. قسم المكتبة (Library System) ====================
            tp_library = new TabPage();
            gb_library = new GroupBox();
            lbl_bookSearch = new Label();
            txt_bookSearch = new TextBox();
            btn_libWhere = new Button();
            btn_libGroupBy = new Button();
            btn_libDistinct = new Button();
            lb_libraryResult = new ListBox();

            // ==================== 4. قسم الجامعة والطلاب (University & Students) ====================
            tp_university = new TabPage();
            gb_university = new GroupBox();
            btn_uniAverage = new Button();
            btn_uniMaxMin = new Button();
            btn_uniJoin = new Button();
            lb_uniResult = new ListBox();

            menuStrip1.SuspendLayout();
            tc_master.SuspendLayout();
            tp_food.SuspendLayout();
            groupBox1.SuspendLayout();
            tp_cars.SuspendLayout();
            gb_cars.SuspendLayout();
            tp_library.SuspendLayout();
            gb_library.SuspendLayout();
            tp_university.SuspendLayout();
            gb_university.SuspendLayout();
            SuspendLayout();

            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, exitToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1020, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";

            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newToolStripMenuItem, aboutToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(46, 24);
            fileToolStripMenuItem.Text = "File";

            newToolStripMenuItem.Name = "newToolStripMenuItem";
            newToolStripMenuItem.Size = new Size(131, 26);
            newToolStripMenuItem.Text = "New";

            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(131, 26);
            aboutToolStripMenuItem.Text = "About";

            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(47, 24);
            exitToolStripMenuItem.Text = "Exit";

            // 
            // tc_master
            // 
            tc_master.Controls.Add(tp_food);
            tc_master.Controls.Add(tp_cars);
            tc_master.Controls.Add(tp_library);
            tc_master.Controls.Add(tp_university);
            tc_master.Location = new Point(12, 40);
            tc_master.Name = "tc_master";
            tc_master.SelectedIndex = 0;
            tc_master.Size = new Size(990, 550);
            tc_master.TabIndex = 1;

            // ==================== 1. TP_FOOD DESIGN ====================
            tp_food.Controls.Add(groupBox1);
            tp_food.Location = new Point(4, 29);
            tp_food.Name = "tp_food";
            tp_food.Padding = new Padding(3);
            tp_food.Size = new Size(982, 517);
            tp_food.TabIndex = 0;
            tp_food.Text = "1. Food & Orders";
            tp_food.UseVisualStyleBackColor = true;

            groupBox1.Controls.Add(lb_foodResult);
            groupBox1.Controls.Add(btn_foodLinqSum);
            groupBox1.Controls.Add(btn_processFood);
            groupBox1.Controls.Add(dtp_order);
            groupBox1.Controls.Add(cb_quantity);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(20, 20);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(940, 470);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Food Orders & LINQ Operations";

            label1.AutoSize = true;
            label1.Location = new Point(25, 45);
            label1.Name = "label1";
            label1.Size = new Size(65, 20);
            label1.Text = "Quantity";

            label2.AutoSize = true;
            label2.Location = new Point(25, 95);
            label2.Name = "label2";
            label2.Size = new Size(83, 20);
            label2.Text = "Order Date";

            cb_quantity.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_quantity.FormattingEnabled = true;
            cb_quantity.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9" });
            cb_quantity.Location = new Point(120, 42);
            cb_quantity.Name = "cb_quantity";
            cb_quantity.Size = new Size(150, 28);

            dtp_order.Format = DateTimePickerFormat.Short;
            dtp_order.Location = new Point(120, 92);
            dtp_order.Name = "dtp_order";
            dtp_order.Size = new Size(150, 27);

            btn_processFood.Location = new Point(300, 40);
            btn_processFood.Name = "btn_processFood";
            btn_processFood.Size = new Size(150, 35);
            btn_processFood.Text = "Process Order";
            btn_processFood.UseVisualStyleBackColor = true;

            btn_foodLinqSum.Location = new Point(300, 85);
            btn_foodLinqSum.Name = "btn_foodLinqSum";
            btn_foodLinqSum.Size = new Size(150, 35);
            btn_foodLinqSum.Text = "LINQ: Total Revenue";
            btn_foodLinqSum.UseVisualStyleBackColor = true;

            lb_foodResult.FormattingEnabled = true;
            lb_foodResult.Location = new Point(25, 145);
            lb_foodResult.Name = "lb_foodResult";
            lb_foodResult.Size = new Size(890, 304);

            // ==================== 2. TP_CARS DESIGN ====================
            tp_cars.Controls.Add(gb_cars);
            tp_cars.Location = new Point(4, 29);
            tp_cars.Name = "tp_cars";
            tp_cars.Padding = new Padding(3);
            tp_cars.Size = new Size(982, 517);
            tp_cars.TabIndex = 1;
            tp_cars.Text = "2. Cars Management";
            tp_cars.UseVisualStyleBackColor = true;

            gb_cars.Controls.Add(lb_carsResult);
            gb_cars.Controls.Add(btn_carsSelect);
            gb_cars.Controls.Add(btn_carsOrderBy);
            gb_cars.Controls.Add(btn_carsWhere);
            gb_cars.Controls.Add(txt_carBrand);
            gb_cars.Controls.Add(lbl_carBrand);
            gb_cars.Location = new Point(20, 20);
            gb_cars.Name = "gb_cars";
            gb_cars.Size = new Size(940, 470);
            gb_cars.TabIndex = 0;
            gb_cars.TabStop = false;
            gb_cars.Text = "Cars Inventory & Advanced LINQ Queries";

            lbl_carBrand.AutoSize = true;
            lbl_carBrand.Location = new Point(25, 45);
            lbl_carBrand.Size = new Size(90, 20);
            lbl_carBrand.Text = "Car Brand:";

            txt_carBrand.Location = new Point(125, 42);
            txt_carBrand.Size = new Size(180, 27);

            btn_carsWhere.Location = new Point(320, 40);
            btn_carsWhere.Size = new Size(120, 35);
            btn_carsWhere.Text = "LINQ Where";
            btn_carsWhere.UseVisualStyleBackColor = true;

            btn_carsOrderBy.Location = new Point(455, 40);
            btn_carsOrderBy.Size = new Size(120, 35);
            btn_carsOrderBy.Text = "LINQ OrderBy";
            btn_carsOrderBy.UseVisualStyleBackColor = true;

            btn_carsSelect.Location = new Point(590, 40);
            btn_carsSelect.Size = new Size(120, 35);
            btn_carsSelect.Text = "LINQ Select";
            btn_carsSelect.UseVisualStyleBackColor = true;

            lb_carsResult.FormattingEnabled = true;
            lb_carsResult.Location = new Point(25, 95);
            lb_carsResult.Size = new Size(890, 350);

            // ==================== 3. TP_LIBRARY DESIGN ====================
            tp_library.Controls.Add(gb_library);
            tp_library.Location = new Point(4, 29);
            tp_library.Name = "tp_library";
            tp_library.Padding = new Padding(3);
            tp_library.Size = new Size(982, 517);
            tp_library.TabIndex = 2;
            tp_library.Text = "3. Library System";
            tp_library.UseVisualStyleBackColor = true;

            gb_library.Controls.Add(lb_libraryResult);
            gb_library.Controls.Add(btn_libDistinct);
            gb_library.Controls.Add(btn_libGroupBy);
            gb_library.Controls.Add(btn_libWhere);
            gb_library.Controls.Add(txt_bookSearch);
            gb_library.Controls.Add(lbl_bookSearch);
            gb_library.Location = new Point(20, 20);
            gb_library.Name = "gb_library";
            gb_library.Size = new Size(940, 470);
            gb_library.TabIndex = 0;
            gb_library.TabStop = false;
            gb_library.Text = "Library Books & LINQ Filters";

            lbl_bookSearch.AutoSize = true;
            lbl_bookSearch.Location = new Point(25, 45);
            lbl_bookSearch.Size = new Size(95, 20);
            lbl_bookSearch.Text = "Search Book:";

            txt_bookSearch.Location = new Point(130, 42);
            txt_bookSearch.Size = new Size(180, 27);

            btn_libWhere.Location = new Point(325, 40);
            btn_libWhere.Size = new Size(120, 35);
            btn_libWhere.Text = "Search (Where)";
            btn_libWhere.UseVisualStyleBackColor = true;

            btn_libGroupBy.Location = new Point(460, 40);
            btn_libGroupBy.Size = new Size(120, 35);
            btn_libGroupBy.Text = "LINQ GroupBy";
            btn_libGroupBy.UseVisualStyleBackColor = true;

            btn_libDistinct.Location = new Point(595, 40);
            btn_libDistinct.Size = new Size(120, 35);
            btn_libDistinct.Text = "LINQ Distinct";
            btn_libDistinct.UseVisualStyleBackColor = true;

            lb_libraryResult.FormattingEnabled = true;
            lb_libraryResult.Location = new Point(25, 95);
            lb_libraryResult.Size = new Size(890, 350);

            // ==================== 4. TP_UNIVERSITY DESIGN ====================
            tp_university.Controls.Add(gb_university);
            tp_university.Location = new Point(4, 29);
            tp_university.Name = "tp_university";
            tp_university.Padding = new Padding(3);
            tp_university.Size = new Size(982, 517);
            tp_university.TabIndex = 3;
            tp_university.Text = "4. University & Students";
            tp_university.UseVisualStyleBackColor = true;

            gb_university.Controls.Add(lb_uniResult);
            gb_university.Controls.Add(btn_uniJoin);
            gb_university.Controls.Add(btn_uniMaxMin);
            gb_university.Controls.Add(btn_uniAverage);
            gb_university.Location = new Point(20, 20);
            gb_university.Name = "gb_university";
            gb_university.Size = new Size(940, 470);
            gb_university.TabIndex = 0;
            gb_university.TabStop = false;
            gb_university.Text = "Students, Grades & Advanced Exam LINQ";

            btn_uniAverage.Location = new Point(25, 40);
            btn_uniAverage.Size = new Size(160, 40);
            btn_uniAverage.Text = "LINQ Average Score";
            btn_uniAverage.UseVisualStyleBackColor = true;

            btn_uniMaxMin.Location = new Point(200, 40);
            btn_uniMaxMin.Size = new Size(160, 40);
            btn_uniMaxMin.Text = "LINQ Max & Min";
            btn_uniMaxMin.UseVisualStyleBackColor = true;

            btn_uniJoin.Location = new Point(375, 40);
            btn_uniJoin.Size = new Size(160, 40);
            btn_uniJoin.Text = "LINQ Join Tables";
            btn_uniJoin.UseVisualStyleBackColor = true;

            lb_uniResult.FormattingEnabled = true;
            lb_uniResult.Location = new Point(25, 95);
            lb_uniResult.Size = new Size(890, 350);

            // ==================== FORM SETTINGS ====================
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1020, 610);
            Controls.Add(tc_master);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Ultimate Exam Revision Master - C# Windows Forms & LINQ";

            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            tc_master.ResumeLayout(false);
            tp_food.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            tp_cars.ResumeLayout(false);
            gb_cars.ResumeLayout(false);
            gb_cars.PerformLayout();
            tp_library.ResumeLayout(false);
            gb_library.ResumeLayout(false);
            gb_library.PerformLayout();
            tp_university.ResumeLayout(false);
            gb_university.ResumeLayout(false);
            gb_university.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem newToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;

        private TabControl tc_master;

        // 1. Food Tab Controls
        private TabPage tp_food;
        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private ComboBox cb_quantity;
        private DateTimePicker dtp_order;
        private Button btn_processFood;
        private Button btn_foodLinqSum;
        private ListBox lb_foodResult;

        // 2. Cars Tab Controls
        private TabPage tp_cars;
        private GroupBox gb_cars;
        private Label lbl_carBrand;
        private TextBox txt_carBrand;
        private Button btn_carsWhere;
        private Button btn_carsOrderBy;
        private Button btn_carsSelect;
        private ListBox lb_carsResult;

        // 3. Library Tab Controls
        private TabPage tp_library;
        private GroupBox gb_library;
        private Label lbl_bookSearch;
        private TextBox txt_bookSearch;
        private Button btn_libWhere;
        private Button btn_libGroupBy;
        private Button btn_libDistinct;
        private ListBox lb_libraryResult;

        // 4. University Tab Controls
        private TabPage tp_university;
        private GroupBox gb_university;
        private Button btn_uniAverage;
        private Button btn_uniMaxMin;
        private Button btn_uniJoin;
        private ListBox lb_uniResult;
    }
}